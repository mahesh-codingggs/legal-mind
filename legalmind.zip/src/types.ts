export enum RiskLevel {
  GREEN = "GREEN",
  YELLOW = "YELLOW",
  RED = "RED"
}

export interface LegalClause {
  id: string;
  category: string;
  originalText: string;
  simplifiedText: string;
  rating: RiskLevel;
  explanation: string;
}

export interface RecommendationList {
  thingsToAsk: string[];
  thingsToNegotiate: string[];
  importantQuestions: string[];
  missingInformation: string[];
  possibleRisks: string[];
  suggestedNextSteps: string[];
}

export interface AnalysisSummary {
  short: string;
  medium: string;
  detailed: string;
  bulletPoints: string[];
}

export interface DocumentAnalysis {
  id: string;
  title: string;
  documentType: string;
  language: string;
  riskScore: number; // 0 to 100
  riskLabel: string; // e.g. "Very Safe", "Moderate Risk", "High Risk"
  summary: AnalysisSummary;
  clauses: LegalClause[];
  recommendations: RecommendationList;
  uploadedAt: string;
  rawText: string;
}

export interface ComparisonDiff {
  title: string;
  description: string;
  status: "added" | "removed" | "modified" | "unchanged";
  doc1Text?: string;
  doc2Text?: string;
}

export interface ComparisonResult {
  doc1Title: string;
  doc2Title: string;
  summary: string;
  overallRiskChange: string; // e.g. "Significantly Higher Risk", "Safer", etc.
  differences: ComparisonDiff[];
  addedClauses: string[];
  removedClauses: string[];
  paymentDifferences: string[];
  riskChanges: string[];
  comparedAt: string;
}

export interface ChatMessage {
  id: string;
  sender: "user" | "ai";
  text: string;
  timestamp: string;
}

export interface SavedAnalysis {
  id: string;
  title: string;
  rawText: string;
  analysis: DocumentAnalysis;
  chatHistory: ChatMessage[];
  savedAt: string;
}

export interface LegalTemplate {
  id: string;
  title: string;
  category: string;
  description: string;
  rawText: string;
}

export interface AppUser {
  email: string;
  name: string;
  isGuest: boolean;
  avatar?: string;
}
