import React, { useState } from "react";
import { 
  RefreshCw, FileText, ArrowRight, ShieldAlert, Sparkles, Check, 
  Trash2, ShieldCheck, HelpCircle, TrendingUp, DollarSign, PlusCircle, MinusCircle 
} from "lucide-react";
import { motion } from "motion/react";
import { ComparisonResult } from "../types";

interface CompareViewProps {
  onCompare: (doc1Text: string, doc1Title: string, doc2Text: string, doc2Title: string) => Promise<ComparisonResult | null>;
  isLoading: boolean;
}

export default function CompareView({ onCompare, isLoading }: CompareViewProps) {
  const [doc1Title, setDoc1Title] = useState("NDA Draft v1");
  const [doc1Text, setDoc1Text] = useState("");
  const [doc2Title, setDoc2Title] = useState("NDA Revised v2");
  const [doc2Text, setDoc2Text] = useState("");
  const [comparison, setComparison] = useState<ComparisonResult | null>(null);
  const [errorMessage, setErrorMessage] = useState("");

  const loadSampleComparison = () => {
    setDoc1Title("Standard Lease Draft");
    setDoc1Text(`RESIDENTIAL LEASE CONTRACT
1. Term: The rent shall run for a duration of 12 months.
2. Security: Resident deposits $2,000 as security.
3. Access: Landlord shall notify tenant 24 hours prior to standard maintenance visits.`);
    
    setDoc2Title("Revised Predatory Landlord Draft");
    setDoc2Text(`RESIDENTIAL LEASE AGREEMENT (REVISED)
1. Term: The lease shall run for 12 months. It AUTOMATICALLY RENEWS for another 12-month period unless Tenant provides registered notice exactly 90 days prior.
2. Security: Resident deposits $3,000 security deposit. If Resident vacates early, the entire security deposit is forfeited.
3. Access: Landlord preserves keys and reserves the absolute right of immediate unannounced entry at any hour for safety reviews.`);
  };

  const handleClear = () => {
    setDoc1Title("NDA Draft v1");
    setDoc1Text("");
    setDoc2Title("NDA Revised v2");
    setDoc2Text("");
    setComparison(null);
    setErrorMessage("");
  };

  const handleRunComparison = async () => {
    setErrorMessage("");
    if (!doc1Text.trim() || !doc2Text.trim()) {
      setErrorMessage("Please supply contract text for BOTH Document 1 and Document 2 to process comparisons.");
      return;
    }
    try {
      const res = await onCompare(doc1Text, doc1Title, doc2Text, doc2Title);
      if (res) {
        setComparison(res);
      }
    } catch (e: any) {
      setErrorMessage(e?.message || "Failed to run comparison. Please ensure your Gemini API is online.");
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Upper header */}
      <div className="text-center sm:text-left">
        <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight flex items-center justify-center sm:justify-start gap-2.5">
          <RefreshCw className="w-7 h-7 text-indigo-600 animate-spin-slow" />
          Intellectual Document Comparison
        </h2>
        <p className="text-sm text-slate-500 mt-1 max-w-3xl leading-relaxed">
          Compare different drafts or proposals side-by-side. 
          Our AI scans details, highlights added/removed elements, evaluates liability shifts, and warns you of payment policy changes.
        </p>
      </div>

      {errorMessage && (
        <div className="p-4 bg-red-50 border border-red-100 rounded-xl text-xs font-semibold text-red-800 flex items-center gap-2">
          <ShieldAlert className="w-5 h-5 text-red-600 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Comparison Input Panels */}
      {!comparison && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <span className="text-[11px] bg-indigo-50 border border-indigo-100 text-indigo-700 font-bold px-3 py-1 rounded-full uppercase tracking-wider">
              Dual Ingestion Workspace
            </span>
            <button
              onClick={loadSampleComparison}
              className="text-xs font-bold text-indigo-600 hover:text-indigo-950 flex items-center gap-1.5 bg-indigo-50/50 hover:bg-indigo-50 px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              Preload Predatory Lease Comparison Drafts
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Document 1 Box */}
            <div className="p-5 bg-white border border-slate-200 shadow-sm rounded-2xl space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Document 1 Title</label>
                <input
                  type="text"
                  value={doc1Title}
                  onChange={(e) => setDoc1Title(e.target.value)}
                  className="w-full px-3 py-2 text-xs font-bold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900"
                  placeholder="e.g. Initial Offer"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Terms / Copy-Paste Text</label>
                <textarea
                  value={doc1Text}
                  onChange={(e) => setDoc1Text(e.target.value)}
                  rows={9}
                  className="w-full p-4 text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900 font-mono"
                  placeholder="Paste the legal clauses, conditions, or text of the first draft..."
                />
              </div>
            </div>

            {/* Document 2 Box */}
            <div className="p-5 bg-white border border-slate-200 shadow-sm rounded-2xl space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Document 2 Title (Revised version)</label>
                <input
                  type="text"
                  value={doc2Title}
                  onChange={(e) => setDoc2Title(e.target.value)}
                  className="w-full px-3 py-2 text-xs font-bold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900"
                  placeholder="e.g. Signed Draft"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Terms / Copy-Paste Text</label>
                <textarea
                  value={doc2Text}
                  onChange={(e) => setDoc2Text(e.target.value)}
                  rows={9}
                  className="w-full p-4 text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900 font-mono"
                  placeholder="Paste the legal clauses, conditions, or revised text to compare..."
                />
              </div>
            </div>
          </div>

          <div className="flex items-center justify-end gap-3.5">
            <button
              onClick={handleClear}
              className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200/80 text-slate-700 font-bold text-xs rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Trash2 className="w-4 h-4 text-slate-400" />
              Clear Fields
            </button>
            <button
              onClick={handleRunComparison}
              disabled={isLoading}
              className="px-6 py-3 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer"
            >
              {isLoading ? "Analyzing drafts..." : "Run AI Comparison"}
              <ArrowRight className="w-4 h-4 text-slate-300" />
            </button>
          </div>
        </div>
      )}

      {/* Comparison Results Area */}
      {comparison && (
        <div className="space-y-6">
          {/* Back button */}
          <div className="flex justify-between items-center bg-slate-100 p-4 rounded-2xl">
            <div>
              <p className="text-xs text-slate-500 font-semibold uppercase">Comparison Complete</p>
              <h3 className="text-xs sm:text-sm font-extrabold text-slate-900 mt-0.5">
                {comparison.doc1Title} <span className="text-indigo-600 font-bold">vs</span> {comparison.doc2Title}
              </h3>
            </div>
            <button
              onClick={() => setComparison(null)}
              className="px-4 py-2 text-xs font-bold bg-white text-slate-800 hover:bg-slate-50 border border-slate-200 rounded-xl transition-all cursor-pointer"
            >
              Modify Drafts
            </button>
          </div>

          {/* Quick Stats Panel */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="p-4 bg-white border border-slate-200 rounded-xl space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Risk Evolution</span>
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-indigo-500" />
                <span className="text-xs font-bold text-indigo-950 uppercase">{comparison.overallRiskChange}</span>
              </div>
            </div>

            <div className="p-4 bg-white border border-slate-200 rounded-xl space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Added Clauses</span>
              <span className="text-lg font-black text-rose-600">{comparison.addedClauses?.length || 0} items</span>
            </div>

            <div className="p-4 bg-white border border-slate-200 rounded-xl space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Removed Clauses</span>
              <span className="text-lg font-black text-emerald-600">{comparison.removedClauses?.length || 0} items</span>
            </div>

            <div className="p-4 bg-white border border-slate-200 rounded-xl space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Financial Changes</span>
              <div className="flex items-center gap-1">
                <DollarSign className="w-4 h-4 text-emerald-600" />
                <span className="text-xs font-bold text-slate-800">{comparison.paymentDifferences?.length > 0 ? `${comparison.paymentDifferences.length} Shifts` : "No Change"}</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main summary view - LHS */}
            <div className="lg:col-span-2 space-y-6">
              {/* Executive Summary Card */}
              <div className="p-5 bg-white border border-slate-200 shadow-xs rounded-2xl space-y-3">
                <h4 className="text-sm font-black text-slate-900 border-b border-slate-100 pb-2 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-indigo-600" />
                  Comparative Executive Analysis
                </h4>
                <p className="text-xs text-slate-600 leading-relaxed font-semibold">
                  {comparison.summary}
                </p>
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-[10px] text-amber-900 font-medium">
                  <strong>Reminder:</strong> Carefully view added conditions. Subtle word shifts in liabilities can lead to heavy financial obligations.
                </div>
              </div>

              {/* Logical Structural Differences List */}
              <div className="p-5 bg-white border border-slate-200 shadow-xs rounded-2xl space-y-4">
                <h4 className="text-sm font-black text-slate-900 pb-2 border-b border-slate-100 uppercase tracking-wide">
                  Clause-by-Clause Variations Detail
                </h4>
                
                <div className="space-y-4">
                  {comparison.differences.map((diff, idx) => (
                    <div key={idx} className="p-4 bg-slate-50 border border-slate-150/80 rounded-xl space-y-3">
                      <div className="flex items-center justify-between">
                        <h5 className="text-xs font-bold text-slate-900">{diff.title}</h5>
                        <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                          diff.status === "added" ? "bg-rose-50 text-rose-700 border border-rose-100" :
                          diff.status === "removed" ? "bg-emerald-50 text-emerald-700 border border-emerald-100" :
                          diff.status === "modified" ? "bg-amber-50 text-amber-700 border border-amber-100" :
                          "bg-slate-100 text-slate-600"
                        }`}>
                          {diff.status}
                        </span>
                      </div>

                      <p className="text-xs text-slate-500 font-semibold">{diff.description}</p>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-[10px] font-mono p-3 bg-white border border-slate-100 rounded-lg">
                        <div>
                          <p className="text-slate-400 font-bold uppercase text-[8px] mb-1">{comparison.doc1Title}</p>
                          <p className="text-slate-600 line-clamp-4">{diff.doc1Text || "— Segment not present —"}</p>
                        </div>
                        <div className="border-t md:border-t-0 md:border-l border-slate-100 pt-2 md:pt-0 md:pl-3">
                          <p className="text-indigo-400 font-bold uppercase text-[8px] mb-1">{comparison.doc2Title}</p>
                          <p className="text-indigo-950 line-clamp-4 font-semibold">{diff.doc2Text || "— Segment deleted —"}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Quick insights rail - RHS */}
            <div className="space-y-6">
              {/* Added clauses itemizers */}
              <div className="p-5 bg-white border border-slate-200 rounded-2xl space-y-3 shadow-xs">
                <h4 className="text-xs font-black text-rose-700 uppercase tracking-widest flex items-center gap-1">
                  <PlusCircle className="w-4 h-4 text-rose-600" /> Elements Introduced
                </h4>
                {comparison.addedClauses?.length > 0 ? (
                  <ul className="space-y-2">
                    {comparison.addedClauses.map((add, i) => (
                      <li key={i} className="text-xs text-slate-600 font-medium list-disc pl-1 ml-4 leading-normal">{add}</li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-xs text-slate-400 italic">No brand new classes added.</p>
                )}
              </div>

              {/* Removed items check */}
              <div className="p-5 bg-white border border-slate-200 rounded-2xl space-y-3 shadow-xs">
                <h4 className="text-xs font-black text-emerald-700 uppercase tracking-widest flex items-center gap-1">
                  <MinusCircle className="w-4 h-4 text-emerald-600" /> Clauses Deleted
                </h4>
                {comparison.removedClauses?.length > 0 ? (
                  <ul className="space-y-2">
                    {comparison.removedClauses.map((rem, i) => (
                      <li key={i} className="text-xs text-slate-600 font-medium list-disc pl-1 ml-4 leading-normal">{rem}</li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-xs text-slate-400 italic">No standard clauses deleted.</p>
                )}
              </div>

              {/* Shifting risks list */}
              <div className="p-5 bg-white border border-indigo-100/80 bg-indigo-50/10 rounded-2xl space-y-3 shadow-xs">
                <h4 className="text-xs font-black text-indigo-900 uppercase tracking-widest flex items-center gap-1">
                  <ShieldAlert className="w-4 h-4 text-indigo-500" /> Core Risk Shifts
                </h4>
                {comparison.riskChanges?.length > 0 ? (
                  <ul className="space-y-2.5">
                    {comparison.riskChanges.map((rc, i) => (
                      <li key={i} className="text-xs text-indigo-950 font-medium bg-indigo-50/50 p-2 border border-indigo-100/50 rounded-lg">{rc}</li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-xs text-indigo-400 italic">Slightly matching risk positions.</p>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
