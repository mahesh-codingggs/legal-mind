import React, { useState, useRef } from "react";
import { 
  Upload, FileText, Sparkles, Search, Clipboard, Image, Trash2, 
  SearchCode, ShieldAlert, CheckCircle, Bell, History, ArrowRight, RefreshCw
} from "lucide-react";
import { SavedAnalysis } from "../types";

interface DashboardProps {
  savedAnalyses: SavedAnalysis[];
  onAnalyzeText: (text: string, title?: string, language?: string) => Promise<void>;
  onAnalyzeImage: (base64: string, mime: string, title?: string, language?: string) => Promise<void>;
  onSelectAnalysis: (item: SavedAnalysis) => void;
  onDeleteAnalysis: (id: string) => void;
  isLoading: boolean;
  activeLanguage: string;
}

export default function Dashboard({
  savedAnalyses,
  onAnalyzeText,
  onAnalyzeImage,
  onSelectAnalysis,
  onDeleteAnalysis,
  isLoading,
  activeLanguage
}: DashboardProps) {
  const [activeInputTab, setActiveInputTab] = useState<"upload" | "paste">("upload");
  const [pastedText, setPastedText] = useState("");
  const [pastedTitle, setPastedTitle] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [isDragOver, setIsDragOver] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Applet Notification states
  const [notification, setNotification] = useState<{ message: string; type: "success" | "info" | "error" } | null>(null);

  const showNotification = (msg: string, type: "success" | "info" | "error" = "success") => {
    setNotification({ message: msg, type });
    setTimeout(() => setNotification(null), 4000);
  };

  // Helper routine to convert file to base64 helper
  const processUploadFile = (file: File) => {
    setErrorMessage("");
    if (!file) return;

    const mime = file.type;
    const isImage = mime.startsWith("image/");
    const isText = mime === "text/plain";

    if (!isImage && !isText && !file.name.endsWith(".txt") && !file.name.endsWith(".docx") && !file.name.endsWith(".pdf")) {
      setErrorMessage("Please supply standard supported formats (.txt, .png, .jpg, .jpeg, or screenshots). For complex PDFs, please copy-paste original copy blocks inside Paste Text.");
      showNotification("Format review required", "error");
      return;
    }

    const reader = new FileReader();

    if (isImage) {
      showNotification("Image loaded. Processing OCR scanning...");
      reader.onload = async (e) => {
        const fullResult = e.target?.result as string;
        const splitBase = fullResult.split(",")[1];
        if (splitBase) {
          try {
            await onAnalyzeImage(splitBase, mime, file.name, activeLanguage);
            showNotification("OCR scanning complete. Analysis Loaded!", "success");
          } catch (err: any) {
            setErrorMessage(err?.message || "OCR service failed. Make sure server is alive.");
            showNotification("Processing failed", "error");
          }
        }
      };
      reader.readAsDataURL(file);
    } else {
      showNotification("Reading text content...");
      reader.onload = async (e) => {
        const textContent = e.target?.result as string;
        if (textContent.trim()) {
          try {
            await onAnalyzeText(textContent, file.name, activeLanguage);
            showNotification("Contract uploaded successfully. Analysis Loaded!", "success");
          } catch (err: any) {
            setErrorMessage(err?.message || "Analysis failed.");
            showNotification("Processing failed", "error");
          }
        } else {
          setErrorMessage("The uploaded file was empty.");
        }
      };
      reader.readAsText(file);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (isLoading) return;
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      processUploadFile(files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      processUploadFile(files[0]);
    }
  };

  const handlePasteSubmit = async () => {
    setErrorMessage("");
    if (!pastedText.trim()) {
      setErrorMessage("Please input contract terms in the workspace field.");
      return;
    }
    try {
      showNotification("Analyzing pasted content...");
      await onAnalyzeText(pastedText, pastedTitle || "Pasted Contract", activeLanguage);
      showNotification("Analysis succeeded!", "success");
      setPastedText("");
      setPastedTitle("");
    } catch (err: any) {
      setErrorMessage(err?.message || "Analysis failed. Verify GEMINI_API_KEY.");
      showNotification("Processing failed", "error");
    }
  };

  // Filter previous analyses
  const filteredAnalyses = savedAnalyses.filter(item => 
    item.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.rawText?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.analysis?.documentType?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      
      {/* 1. Dynamic Notification Toast Banner */}
      {notification && (
        <div className="fixed top-20 right-4 z-50 flex items-center gap-3 p-4 bg-slate-900 border border-slate-700/80 text-white rounded-2xl shadow-2xl animate-fade-in text-xs max-w-sm select-none">
          <Bell className="w-5 h-5 text-indigo-400 shrink-0" />
          <div className="flex-1">
            <span className="font-semibold block">{notification.message}</span>
            <span className="text-[10px] text-slate-400 font-medium">Automatic advisory alert</span>
          </div>
          {notification.type === "success" ? (
            <CheckCircle className="w-4 h-4 text-emerald-400" />
          ) : (
            <ShieldAlert className="w-4 h-4 text-rose-400" />
          )}
        </div>
      )}

      {/* Hero Welcome Headers */}
      <div className="text-center sm:text-left space-y-2">
        <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight leading-none">
          LegalMind Analysis Desk
        </h2>
        <p className="text-sm text-slate-500 font-semibold max-w-3xl leading-normal">
          Upload file drafts, capture snapshot images, or paste text. 
          Our server-side AI automatically performs OCR indexing, clause extraction, color-coded safety metrics parsing, and summarizes your document.
        </p>
      </div>

      {errorMessage && (
        <div className="p-4 bg-rose-50 border border-rose-100 rounded-xl text-xs font-bold text-rose-800 flex items-start gap-2.5">
          <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <span>{errorMessage}</span>
            <p className="text-[10px] font-medium text-rose-500">How to fix: Make sure process.env.GEMINI_API_KEY is defined in AI Studio Secrets panel.</p>
          </div>
        </div>
      )}

      {/* Main Workspace Grid: input sections LHS, history records RHS */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Input area LHS */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Tab Selector Buttons */}
          <div className="flex bg-slate-100 p-1 border border-slate-200 rounded-2xl max-w-xs shadow-xs text-xs font-bold">
            <button
              onClick={() => { setActiveInputTab("upload"); setErrorMessage(""); }}
              className={`flex-1 py-2 text-center rounded-xl flex items-center justify-center gap-1.5 transition-all ${activeInputTab === "upload" ? "bg-white text-slate-950 font-black shadow-xs" : "text-slate-500 hover:text-slate-900"}`}
            >
              <Upload className="w-4 h-4" />
              Upload Document
            </button>
            <button
              onClick={() => { setActiveInputTab("paste"); setErrorMessage(""); }}
              className={`flex-1 py-2 text-center rounded-xl flex items-center justify-center gap-1.5 transition-all ${activeInputTab === "paste" ? "bg-white text-slate-950 font-black shadow-xs" : "text-slate-500 hover:text-slate-900"}`}
            >
              <Clipboard className="w-4 h-4" />
              Paste Text
            </button>
          </div>

          {/* Active Input Panel content */}
          {activeInputTab === "upload" ? (
            <div 
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-3xl p-10 sm:p-14 text-center cursor-pointer transition-all space-y-5 bg-white relative ${
                isDragOver ? "border-indigo-600 bg-indigo-50/20 shadow-inner" : "border-slate-250 hover:border-slate-350 hover:shadow-md"
              }`}
            >
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                disabled={isLoading}
                className="hidden"
                accept=".txt, .png, .jpg, .jpeg, .pdf, .docx, image/*"
              />

              <div className="flex flex-col items-center justify-center space-y-3">
                <div className="p-4 bg-indigo-50 text-indigo-700 rounded-full inline-block">
                  <Upload className="w-8 h-8" />
                </div>
                <h4 className="font-extrabold text-slate-800 text-sm">Drag & Drop legal file or snapshot image here</h4>
                <p className="text-[11px] text-slate-400 font-medium max-w-md mx-auto">
                  Supports TXT draft forms, PNG/JPG screenshot snapshots directly. 
                  Once loaded, our multimodal model reads raw terms via integrated OCR.
                </p>
              </div>

              {isLoading ? (
                <div className="absolute inset-0 z-10 bg-white/80 flex flex-col items-center justify-center space-y-3 rounded-2xl select-none">
                  <RefreshCw className="w-8 h-8 text-indigo-600 animate-spin" />
                  <p className="text-xs font-black text-indigo-950">Drafting Full Analysis. Please hold...</p>
                  <p className="text-[10px] text-slate-400 font-medium px-4">Processing color scores, recommendations, summaries, and translations via Gemini-3.5</p>
                </div>
              ) : (
                <button
                  type="button"
                  className="px-5 py-2 bg-slate-950 text-white font-bold text-xs rounded-xl shadow-xs hover:bg-slate-850 cursor-pointer"
                >
                  Browse Files
                </button>
              )}
            </div>
          ) : (
            <div className="p-6 bg-white border border-slate-200/80 rounded-3xl space-y-4">
              <div className="space-y-3 relative">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">Contract / Draft Title</label>
                  <input
                    type="text"
                    value={pastedTitle}
                    onChange={(e) => setPastedTitle(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-bold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900"
                    placeholder="e.g. Freelancer Work Agreement"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-1 font-mono">Pasted Legal Terms Body</label>
                  <textarea
                    value={pastedText}
                    onChange={(e) => setPastedText(e.target.value)}
                    rows={8}
                    className="w-full p-4 text-xs font-medium bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900 font-mono"
                    placeholder="Paste the legal clauses, notices, NDA rules, or tenancy obligations here..."
                  />
                </div>

                {isLoading && (
                  <div className="absolute inset-0 z-10 bg-white/85 flex flex-col items-center justify-center space-y-3 rounded-xl select-none">
                    <RefreshCw className="w-8 h-8 text-indigo-600 animate-spin" />
                    <p className="text-xs font-black text-indigo-950">Analyzing Pasted Terms...</p>
                    <p className="text-[10px] text-slate-400 font-semibold px-4">Creating simple language translations and strategic recommendations</p>
                  </div>
                )}
              </div>

              <div className="flex justify-end pt-2 border-t border-slate-50">
                <button
                  onClick={handlePasteSubmit}
                  disabled={isLoading || !pastedText.trim()}
                  className="px-6 py-2.5 bg-slate-900 border border-slate-950 hover:bg-slate-850 disabled:bg-slate-200 hover:shadow-md text-white text-xs font-extrabold rounded-xl shadow-xs transition-all flex items-center gap-2 cursor-pointer"
                >
                  Launch Analysis
                  <ArrowRight className="w-4 h-4 text-indigo-400" />
                </button>
              </div>
            </div>
          )}
        </div>

        {/* History Area RHS */}
        <div className="p-5 bg-white border border-slate-200/80 rounded-3xl space-y-4 shadow-sm flex flex-col h-[460px]">
          
          {/* Header Title count */}
          <div className="shrink-0 space-y-1">
            <h4 className="text-xs font-black text-slate-900 flex items-center gap-1.5 uppercase tracking-wide">
              <History className="w-4 h-4 text-indigo-500" />
              Recent Analysis Workspace
            </h4>
            <p className="text-[10px] text-slate-400 leading-normal">
              Re-open summaries, risk scores, and Chat history from previous uploads.
            </p>
          </div>

          {/* Search bar */}
          <div className="relative shrink-0 flex items-center text-xs text-slate-650">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-350">
              <Search className="w-3.5 h-3.5" />
            </span>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search previous uploads..."
              className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-indigo-600"
            />
          </div>

          {/* List of past ones */}
          <div className="flex-1 overflow-y-auto space-y-2 pr-1.5 scrollbar-thin">
            {filteredAnalyses.length > 0 ? (
              filteredAnalyses.map((item) => {
                const badge = item.analysis?.riskScore < 25 ? "bg-emerald-50 text-emerald-700 border-emerald-100" :
                              item.analysis?.riskScore < 65 ? "bg-amber-50 text-amber-700 border-amber-100" :
                              "bg-rose-50 text-rose-700 border-rose-100";
                return (
                  <div 
                    key={item.id}
                    onClick={() => onSelectAnalysis(item)}
                    className="flex items-center justify-between p-3 border border-slate-150 hover:border-slate-300 hover:shadow-xs rounded-xl cursor-pointer transition-all bg-slate-50/40 hover:bg-white group"
                  >
                    <div className="space-y-1 max-w-[75%]">
                      <h5 className="font-bold text-slate-800 text-xs truncate group-hover:text-indigo-600 transition-colors">
                        {item.title || "Unnamed Document"}
                      </h5>
                      <div className="flex items-center gap-1.5">
                        <span className={`text-[8px] font-extrabold px-1.5 py-0.5 rounded-full border ${badge}`}>
                          Index: {item.analysis?.riskScore}
                        </span>
                        <span className="text-[8px] text-slate-400 font-mono">
                          {new Date(item.savedAt).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                    
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteAnalysis(item.id);
                        showNotification("Deleted document analysis successfully", "info");
                      }}
                      className="p-1.5 text-slate-350 hover:text-red-650 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                      title="Delete analysis record permanently"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                );
              })
            ) : (
              <div className="text-center py-12 text-slate-400 font-bold select-none text-[11px] leading-relaxed">
                <SearchCode className="w-7 h-7 mx-auto text-slate-300 mb-1.5" />
                <p>No matches matching your search.</p>
                <p className="text-[9px] text-slate-350 font-normal">Past uploads represent files saved locally in your active browser session.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
