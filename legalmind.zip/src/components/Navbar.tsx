import React from "react";
import { Scale, LogIn, LogOut, Globe, ClipboardList, RefreshCw, Layers } from "lucide-react";
import { AppUser } from "../types";

interface NavbarProps {
  user: AppUser | null;
  activeLanguage: string;
  onLanguageChange: (lang: string) => void;
  onAuthTrigger: () => void;
  onLogout: () => void;
  activeTab: "home" | "analyze" | "compare" | "templates";
  onTabChange: (tab: "home" | "analyze" | "compare" | "templates") => void;
}

export const supportedLanguages = [
  { code: "English", name: "English" },
  { code: "Hindi", name: "Hindi (हिन्दी)" },
  { code: "Telugu", name: "Telugu (తెలుగు)" },
  { code: "Tamil", name: "Tamil (தமிழ்)" },
  { code: "Kannada", name: "Kannada (ಕನ್ನಡ)" },
  { code: "Malayalam", name: "Malayalam (മലയാളം)" },
  { code: "Marathi", name: "Marathi (मराठी)" },
  { code: "Urdu", name: "Urdu (اردو)" }
];

export default function Navbar({
  user,
  activeLanguage,
  onLanguageChange,
  onAuthTrigger,
  onLogout,
  activeTab,
  onTabChange
}: NavbarProps) {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200/80 bg-white/80 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand Logo */}
        <div 
          onClick={() => onTabChange("home")}
          className="flex items-center gap-2 cursor-pointer group"
          id="brand-logo"
        >
          <div className="p-2.5 rounded-xl bg-slate-900 text-white shadow-md shadow-indigo-950/10 transition-transform group-hover:scale-105">
            <Scale className="w-5 h-5 text-indigo-400" />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight text-slate-900 flex items-center gap-1.5 leading-none">
              LegalMind <span className="text-[10px] py-0.5 px-1.5 rounded-full bg-indigo-50 text-indigo-600 font-bold border border-indigo-100">AI</span>
            </h1>
            <span className="text-[9px] font-medium text-slate-400 tracking-wider">SECURE LEGAL EDUCATION</span>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="hidden md:flex items-center gap-1">
          <button
            onClick={() => onTabChange("home")}
            className={`px-3 py-2 text-xs font-semibold rounded-lg transition-all ${
              activeTab === "home"
                ? "bg-slate-900 text-white shadow-sm"
                : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
            }`}
          >
            Home
          </button>
          <button
            onClick={() => onTabChange("analyze")}
            className={`px-3 py-2 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 ${
              activeTab === "analyze"
                ? "bg-slate-900 text-white shadow-sm"
                : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
            }`}
          >
            <ClipboardList className="w-3.5 h-3.5" />
            Document Workspace
          </button>
          <button
            onClick={() => onTabChange("compare")}
            className={`px-3 py-2 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 ${
              activeTab === "compare"
                ? "bg-slate-900 text-white shadow-sm"
                : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
            }`}
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Compare Contracts
          </button>
          <button
            onClick={() => onTabChange("templates")}
            className={`px-3 py-2 text-xs font-semibold rounded-lg transition-all flex items-center gap-1.5 ${
              activeTab === "templates"
                ? "bg-slate-900 text-white shadow-sm"
                : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            Legal Templates
          </button>
        </nav>

        {/* Right Actions Block */}
        <div className="flex items-center gap-3">
          {/* Translation Picker dropdown */}
          <div className="relative flex items-center gap-1.5 text-xs text-slate-600 bg-slate-50 border border-slate-200/80 px-2.5 py-1.5 rounded-xl">
            <Globe className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={activeLanguage}
              onChange={(e) => onLanguageChange(e.target.value)}
              className="bg-transparent border-none outline-none font-medium text-slate-700 cursor-pointer pr-1 focus:ring-0"
              title="Select analysis explanation language"
            >
              {supportedLanguages.map((lang) => (
                <option key={lang.code} value={lang.code}>
                  {lang.name}
                </option>
              ))}
            </select>
          </div>

          {/* User Log in status */}
          {user ? (
            <div className="flex items-center gap-2">
              <div className="hidden sm:flex flex-col items-end leading-none">
                <span className="text-xs font-bold text-slate-800">{user.name}</span>
                <span className="text-[9px] text-slate-400">
                  {user.isGuest ? "Guest Mode" : "Verified User"}
                </span>
              </div>
              <img
                src={user.avatar || `https://api.dicebear.com/7.x/adventurer/svg?seed=${user.name}`}
                alt="Avatar"
                referrerPolicy="no-referrer"
                className="w-8 h-8 rounded-full border border-slate-200 bg-slate-50 shadow-sm"
              />
              <button
                onClick={onLogout}
                className="p-2 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded-xl transition-colors"
                title="Sign out of LegalMind"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={onAuthTrigger}
              className="flex items-center gap-1.5 px-3.5 py-1.5 sm:py-2 text-xs font-semibold text-white bg-slate-900 border border-slate-950 rounded-xl hover:bg-slate-800 hover:shadow-md transition-all cursor-pointer"
            >
              <LogIn className="w-3.5 h-3.5" />
              Sign In
            </button>
          )}
        </div>
      </div>

      {/* Mobile Sub Navigation bar to ensure full functionality */}
      <div className="flex md:hidden border-t border-slate-100 bg-slate-50 px-4 py-2 justify-between items-center text-xs">
        <button
          onClick={() => onTabChange("home")}
          className={`flex-1 text-center py-1 font-semibold rounded-md ${
            activeTab === "home" ? "bg-slate-200 text-slate-900" : "text-slate-600"
          }`}
        >
          Home
        </button>
        <button
          onClick={() => onTabChange("analyze")}
          className={`flex-1 text-center py-1 font-semibold rounded-md ${
            activeTab === "analyze" ? "bg-slate-200 text-slate-900" : "text-slate-600"
          }`}
        >
          Analyze
        </button>
        <button
          onClick={() => onTabChange("compare")}
          className={`flex-1 text-center py-1 font-semibold rounded-md ${
            activeTab === "compare" ? "bg-slate-200 text-slate-900" : "text-slate-600"
          }`}
        >
          Compare
        </button>
        <button
          onClick={() => onTabChange("templates")}
          className={`flex-1 text-center py-1 font-semibold rounded-md ${
            activeTab === "templates" ? "bg-slate-200 text-slate-900" : "text-slate-600"
          }`}
        >
          Templates
        </button>
      </div>
    </header>
  );
}
