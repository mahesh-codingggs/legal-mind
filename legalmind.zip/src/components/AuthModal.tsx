import React, { useState } from "react";
import { X, Mail, Lock, User, Key, CheckCircle, ShieldAlert } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { AppUser } from "../types";

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (user: AppUser) => void;
}

type AuthMode = "signin" | "signup" | "forgot";

export default function AuthModal({ isOpen, onClose, onLoginSuccess }: AuthModalProps) {
  const [mode, setMode] = useState<AuthMode>("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [successMsg, setSuccessMsg] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage("");
    setSuccessMsg("");
    setIsLoading(true);

    setTimeout(() => {
      setIsLoading(false);
      if (mode === "signin") {
        if (!email || !password) {
          setErrorMessage("Please enter all required credentials.");
          return;
        }
        // Success sign in
        const user: AppUser = {
          email,
          name: email.split("@")[0],
          isGuest: false,
          avatar: `https://api.dicebear.com/7.x/adventurer/svg?seed=${email}`
        };
        onLoginSuccess(user);
        onClose();
      } else if (mode === "signup") {
        if (!email || !password || !name) {
          setErrorMessage("Please fill in all blanks to register.");
          return;
        }
        setSuccessMsg("Account created successfully! Auto-logging in...");
        setTimeout(() => {
          const user: AppUser = {
            email,
            name: name,
            isGuest: false,
            avatar: `https://api.dicebear.com/7.x/adventurer/svg?seed=${name}`
          };
          onLoginSuccess(user);
          onClose();
        }, 1500);
      } else {
        // Forgot
        if (!email) {
          setErrorMessage("Please enter your registered email address.");
          return;
        }
        setSuccessMsg("A secure password reset link has been dispatched to " + email);
      }
    }, 800);
  };

  const handleGoogleLogin = () => {
    setErrorMessage("");
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      const user: AppUser = {
        email: "demo.legalmind@gmail.com",
        name: "Google Member",
        isGuest: false,
        avatar: "https://api.dicebear.com/7.x/adventurer/svg?seed=google_user"
      };
      onLoginSuccess(user);
      onClose();
    }, 1000);
  };

  const handleGuestLogin = () => {
    const user: AppUser = {
      email: "guest@legalmind.local",
      name: "Guest Explorer",
      isGuest: true,
      avatar: "https://api.dicebear.com/7.x/adventurer/svg?seed=guest"
    };
    onLoginSuccess(user);
    onClose();
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="relative w-full max-w-md overflow-hidden bg-white/95 text-slate-900 border border-slate-200 shadow-2xl rounded-2xl"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header Panel */}
          <div className="p-6 bg-gradient-to-br from-slate-900 via-slate-800 to-indigo-950 text-white relative">
            <button
              onClick={onClose}
              className="absolute right-4 top-4 p-1.5 rounded-full text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
              id="close-auth-modal"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 mb-2 text-indigo-400">
              <span className="p-2 bg-white/10 rounded-lg">
                <User className="w-5 h-5" />
              </span>
              <span className="font-semibold tracking-wide text-sm">SECURE GATEWAY</span>
            </div>
            <h3 className="text-2xl font-bold tracking-tight">
              {mode === "signin" && "Sign In to LegalMind"}
              {mode === "signup" && "Create App Account"}
              {mode === "forgot" && "Reset Password"}
            </h3>
            <p className="text-xs text-slate-300 mt-1">
              {mode === "signin" && "Gain access to permanent storage, history records and report downloads."}
              {mode === "signup" && "Take command of your contracts with an AI co-pilot."}
              {mode === "forgot" && "Submit address to secure your credentials."}
            </p>
          </div>

          <div className="p-6">
            {errorMessage && (
              <div className="flex items-center gap-2 p-3 mb-4 text-xs font-medium text-red-700 bg-red-50 border border-red-100 rounded-lg">
                <ShieldAlert className="w-4 h-4 shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            {successMsg && (
              <div className="flex items-center gap-2 p-3 mb-4 text-xs font-semibold text-emerald-700 bg-emerald-50 border border-emerald-100 rounded-lg">
                <CheckCircle className="w-4 h-4 shrink-0" />
                <span>{successMsg}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              {mode === "signup" && (
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">Your Full Name</label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                      <User className="w-4 h-4" />
                    </span>
                    <input
                      type="text"
                      className="w-full pl-9 pr-4 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900 transition-shadow"
                      placeholder="Jane Doe"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      required
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">Email Address</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                    <Mail className="w-4 h-4" />
                  </span>
                  <input
                    type="email"
                    className="w-full pl-9 pr-4 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900 transition-shadow"
                    placeholder="you@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>
              </div>

              {mode !== "forgot" && (
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-semibold text-slate-600">Password</label>
                    {mode === "signin" && (
                      <button
                        type="button"
                        onClick={() => setMode("forgot")}
                        className="text-xs font-medium text-slate-500 hover:text-slate-900 transition-colors"
                      >
                        Forgot password?
                      </button>
                    )}
                  </div>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
                      <Lock className="w-4 h-4" />
                    </span>
                    <input
                      type="password"
                      className="w-full pl-9 pr-4 py-2 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900 transition-shadow"
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                    />
                  </div>
                </div>
              )}

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-2.5 bg-slate-900 text-white font-medium text-sm rounded-xl hover:bg-slate-800 focus:ring-2 focus:ring-slate-900 focus:ring-offset-2 disabled:bg-slate-300 transition-colors shadow-sm"
              >
                {isLoading ? "Validating..." : mode === "signin" ? "Sign In" : mode === "signup" ? "Create Account" : "Dispatch Reset Link"}
              </button>
            </form>

            {mode === "signin" && (
              <>
                <div className="relative flex py-3 items-center">
                  <div className="flex-grow border-t border-slate-200"></div>
                  <span className="flex-shrink mx-4 text-[10px] uppercase tracking-wider font-semibold text-slate-400">or connect via</span>
                  <div className="flex-grow border-t border-slate-200"></div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={handleGoogleLogin}
                    disabled={isLoading}
                    className="flex items-center justify-center gap-2 py-2 px-4 shadow-sm border border-slate-200 text-slate-700 bg-white hover:bg-slate-50 text-xs font-semibold rounded-xl transition-colors"
                  >
                    <svg className="w-4 h-4" viewBox="0 0 24 24">
                      <path
                        fill="#EA4335"
                        d="M12 5.04c1.9 0 3.51.66 4.85 1.93l3.6-3.6C18.18 1.42 15.31.5 12 .5c-4.8 0-8.91 2.68-10.98 6.64l4.13 3.19C6.12 7.37 8.84 5.04 12 5.04z"
                      />
                      <path
                        fill="#4285F4"
                        d="M23.49 12.27c0-.86-.08-1.68-.22-2.48H12v4.69h6.48c-.28 1.47-1.12 2.71-2.37 3.55l3.68 2.85c2.16-1.98 3.7-4.9 3.7-8.61z"
                      />
                      <path
                        fill="#FBBC05"
                        d="M5.15 14.17c-.24-.71-.38-1.47-.38-2.27s.14-1.56.38-2.27L1.02 6.44C.37 7.74 0 9.2 0 10.9s.37 3.16 1.02 4.46l4.13-3.19z"
                      />
                      <path
                        fill="#34A853"
                        d="M12 23.5c3.24 0 5.97-1.07 7.96-2.92l-3.68-2.85c-1.1.74-2.51 1.18-4.28 1.18-3.16 0-5.88-2.33-6.84-5.33L1.02 16.7C3.09 20.66 7.2 23.5 12 23.5z"
                      />
                    </svg>
                    Google Login
                  </button>
                  <button
                    onClick={handleGuestLogin}
                    className="flex items-center justify-center gap-2 py-2 px-4 shadow-sm border border-slate-200 text-slate-700 bg-white hover:bg-slate-50 text-xs font-semibold rounded-xl transition-colors"
                  >
                    Guest Access
                  </button>
                </div>
              </>
            )}

            <div className="mt-6 text-center text-xs">
              {mode === "signin" ? (
                <p className="text-slate-500">
                  New to LegalMind?{" "}
                  <button onClick={() => setMode("signup")} className="font-semibold text-slate-800 hover:underline">
                    Create free account
                  </button>
                </p>
              ) : mode === "signup" ? (
                <p className="text-slate-500">
                  Already have an account?{" "}
                  <button onClick={() => setMode("signin")} className="font-semibold text-slate-800 hover:underline">
                    Sign In
                  </button>
                </p>
              ) : (
                <button onClick={() => setMode("signin")} className="font-semibold text-slate-800 hover:underline">
                  Return to Sign In
                </button>
              )}
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
