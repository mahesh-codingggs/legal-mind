import React, { useState } from "react";
import { 
  ShieldCheck, Sparkles, FileText, Upload, ArrowRight, ShieldAlert, 
  ChevronDown, HelpCircle, User, Star, Languages, MessageSquare, RefreshCw, FileDown, Eye
} from "lucide-react";
import { motion } from "motion/react";

interface HeroSectionProps {
  onStartAnalyzing: () => void;
  onExploreTemplates: () => void;
}

export default function HeroSection({ onStartAnalyzing, onExploreTemplates }: HeroSectionProps) {
  const [activeFaq, setActiveFaq] = useState<number | null>(0);

  const stats = [
    { value: "4.8/5", label: "Client satisfaction" },
    { value: "100%", label: "Privacy encrypted" },
    { value: "50+", label: "Contract categories" },
    { value: "8+ Languages", label: "Realtime translations" }
  ];

  const features = [
    {
      icon: <Sparkles className="w-5 h-5 text-indigo-500" />,
      title: "AI Risk Assessment",
      desc: "Assigns color states (🟢 Safe, 🟡 Caution, 🔴 Toxic Risk) with deep logical reasoning on unfavorable clause liabilities."
    },
    {
      icon: <Languages className="w-5 h-5 text-indigo-500" />,
      title: "Multilingual Explainer",
      desc: "Simplifies legal jargon into plain language. Supports translation into Hindi, Tamil, Telugu, Urdu, and more."
    },
    {
      icon: <MessageSquare className="w-5 h-5 text-indigo-500" />,
      title: "Active Contract Chat",
      desc: "Chat with your agreement. Get instant clarification on hidden termination rights, automatic renewals, or intellectual property rules."
    },
    {
      icon: <RefreshCw className="w-5 h-5 text-indigo-500" />,
      title: "Version Comparison",
      desc: "Compare two revisions of a contract side-by-side to highlight added clauses, deleted rules, and shifting risk ratings."
    },
    {
      icon: <Eye className="w-5 h-5 text-indigo-500" />,
      title: "Optical Multimodal OCR",
      desc: "Instantly analyze scanned document PDFs, mobile camera snapshots, or lease screenshots without typing manually."
    },
    {
      icon: <FileDown className="w-5 h-5 text-indigo-500" />,
      title: "Comprehensive Reports",
      desc: "Download clean, fully structured summaries, risk indexes, warnings, and negotiation check-lists in printable formats."
    }
  ];

  const futureFeatures = [
    { title: "Voice Summaries", description: "Audible explanations to review contracts on-the-go." },
    { title: "Smart Template Generator", description: "Design fair, human-first legal agreements customized to your industry." },
    { title: "Emergency Legal Help Panel", description: "Connect directly with local certified counsel when risky patterns persist." },
    { title: "Fraud Detection Engine", description: "Identify illegal provisions, predatory interest rates, and regulatory violations." }
  ];

  const testimonials = [
    {
      quote: "LegalMind saved me from signing a lease with an unfair 90-day automatic renewal clause. Safe to say, I successfully renegotiated it using the recommendations!",
      author: "Priya Sharma",
      role: "Freelance Designer, Bangalore",
      rating: 5
    },
    {
      quote: "As a student leasing my first apartment, standard legal terminology made absolutely no sense to me. The simple plain English translation made me finally feel empowered and safe.",
      author: "Marcus Miller",
      role: "Graduate Student",
      rating: 5
    },
    {
      quote: "The comparative document analyzer is phenomenal! Saved us hours comparing client contracts against our standard corporate NDA drafts.",
      author: "Evelyn Carter",
      role: "E-Commerce Founder",
      rating: 5
    }
  ];

  const faqs = [
    {
      q: "Does LegalMind provide real binding legal consultation?",
      a: "No. LegalMind is an AI-powered educational framework. It analyzes complex documents, flags hidden liabilities, simplifies legal jargon, and suggests key negotiation questions. It is designed to educate you so you can make informed decisions, but does not replace qualified, licensed legal counsel."
    },
    {
      q: "How secure are my uploaded contracts and sensitive agreements?",
      a: "Security is our highest principle. All transcripts, images, or analyses are processed through secure, industry-leading endpoints and encrypted. We do not sell or share your document data with third parties, and you can permanently delete documents from your dashboard anytime."
    },
    {
      q: "What types of files and document methods do you support?",
      a: "You can copy and paste legal text directly, write contracts manually, or upload files like PDF, DOCX, TXT, and images (PNG, JPG, JPEG). For images and screenshots, our model automatically utilizes modern Optical Character Recognition (OCR) to parse and process terms."
    },
    {
      q: "How does the color-coded Risk Highlighting system operate?",
      a: "Every critical contract segment receives a badge: Green (fair/standard terms), Yellow (items requiring close attention, such as notice periods or auto-bills), and Red (severe risks, unlimited indemnity, hidden charges, or unfair unilateral termination rights)."
    }
  ];

  return (
    <div className="bg-slate-50 text-slate-800">
      {/* 1. Hero Section */}
      <section className="relative overflow-hidden pt-12 pb-20 sm:pb-28">
        {/* Subtle decorative background gradients */}
        <div className="absolute top-0 left-1/2 -z-10 h-[500px] w-full max-w-7xl -translate-x-1/2 [mask-image:radial-gradient(100%_100%_at_top,white,transparent)]">
          <div className="absolute inset-0 bg-linear-to-b from-indigo-100/40 via-transparent to-transparent" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            {/* Tagline Accent */}
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900 text-white text-[11px] font-semibold tracking-wide uppercase mb-6 shadow-sm border border-slate-800">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              <span>EDUCATINAL & PRIVACY-FIRST CO-PILOT</span>
            </div>

            {/* Display Typography */}
            <h2 className="text-4xl sm:text-6xl font-bold tracking-tight text-slate-900 mb-6 leading-none">
              Understand Legal Documents <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-indigo-700 to-indigo-950 font-extrabold">
                in Simple, Layperson English
              </span>
            </h2>

            {/* Subheading */}
            <p className="text-base sm:text-lg text-slate-600 font-medium max-w-2xl mx-auto mb-10 leading-relaxed">
              Don't sign blindly. Upload contracts, agreements, lease receipts, or screenshots. 
              Our AI co-pilot reveals hidden liabilities, estimates risk scores, translates jargon, 
              and equips you to negotiate safely.
            </p>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 mb-16">
              <button
                onClick={onStartAnalyzing}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-7 py-3.5 text-sm font-semibold text-white bg-slate-900 border border-slate-950 rounded-2xl hover:bg-slate-800 hover:shadow-lg hover:-translate-y-0.5 transition-all cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                Analyze a Document
                <ArrowRight className="w-4 h-4 text-slate-400" />
              </button>
              <button
                onClick={onExploreTemplates}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-7 py-3.5 text-sm font-semibold text-slate-700 bg-white border border-slate-200 rounded-2xl hover:bg-slate-50 hover:shadow-md transition-all cursor-pointer"
              >
                <FileText className="w-4 h-4 text-slate-400" />
                Try Interactive Demo
              </button>
            </div>

            {/* Disclaimer Bar */}
            <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 text-[11px] text-amber-900 font-medium leading-relaxed max-w-3xl mx-auto flex items-start gap-2.5 shadow-sm text-left">
              <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <span>
                <strong>Educational Notice:</strong> LegalMind employs advanced server-side language models to map clauses but does NOT provide qualified attorney representation or professional legal advice. Always address critical affairs with a certified legal practitioner.
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Board */}
      <section className="bg-slate-900 text-white py-12 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {stats.map((st, idx) => (
              <div key={idx} className="space-y-1">
                <p className="text-3xl sm:text-4xl font-extrabold text-indigo-400">{st.value}</p>
                <p className="text-xs text-slate-400 font-medium tracking-wide uppercase">{st.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 2. Feature Cards Bento Section */}
      <section className="py-20 sm:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h3 className="text-xs font-bold text-indigo-600 uppercase tracking-widest mb-2">POWERFUL CORE SUITE</h3>
            <h4 className="text-3xl sm:text-4xl font-bold tracking-tight text-slate-900">
              Everything you need to master your contracts
            </h4>
            <p className="text-sm text-slate-500 mt-3 leading-relaxed">
              We leverage advanced artificial intelligence to handle complex text semantics, OCR scanner inputs, and language translations seamlessly.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feat, idx) => (
              <div 
                key={idx} 
                className="p-6 rounded-2xl bg-slate-55 border border-slate-100 hover:border-slate-200 hover:shadow-xl transition-all group hover:-translate-y-1"
                id={`feature-card-${idx}`}
              >
                <div className="p-3 bg-indigo-50 text-indigo-700 rounded-xl inline-block mb-4 transition-transform group-hover:scale-110">
                  {feat.icon}
                </div>
                <h5 className="font-bold text-slate-900 text-lg mb-2">{feat.title}</h5>
                <p className="text-xs text-slate-500 leading-relaxed font-medium">{feat.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 3. Color Highlight Systems Visual Representation */}
      <section className="py-16 bg-slate-50 border-y border-slate-200/50">
        <div className="max-w-6xl mx-auto px-4">
          <div className="bg-slate-900 text-white rounded-3xl p-8 sm:p-12 overflow-hidden shadow-2xl relative">
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-10 items-center">
              <div className="lg:col-span-2 space-y-4">
                <span className="text-[10px] bg-slate-800 text-indigo-400 font-bold px-3 py-1 rounded-full uppercase tracking-wider">Visual Intelligence</span>
                <h3 className="text-2xl sm:text-3xl font-extrabold tracking-tight leading-none text-white">The Color-Coded Risk Rating System</h3>
                <p className="text-xs text-slate-400 leading-relaxed font-semibold">
                  LegalMind scans every line of uploaded text, highlighting clauses under a distinct clinical status so you can assess safety standards within seconds.
                </p>
              </div>

              <div className="lg:col-span-3 space-y-4">
                {/* Green Clause Card */}
                <div className="p-4 bg-slate-800/60 border-l-4 border-emerald-500 rounded-xl">
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                    <span className="text-xs font-bold text-emerald-400 tracking-wider">🟢 GREEN — STANDARD SAFE</span>
                  </div>
                  <p className="text-xs font-medium italic text-slate-300">"Employer agrees to provide regular healthcare insurance options and standard vacation times."</p>
                  <p className="text-[10px] text-slate-400 mt-1">This clause follows standard legal standards and protects baseline rights cleanly.</p>
                </div>

                {/* Yellow Clause Card */}
                <div className="p-4 bg-slate-800/60 border-l-4 border-amber-500 rounded-xl">
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                    <span className="text-xs font-bold text-amber-400 tracking-wider">🟡 YELLOW — REVIEW REQUIRED</span>
                  </div>
                  <p className="text-xs font-medium italic text-slate-300">"This lease automatically renews for another 12-month period unless canceled."</p>
                  <p className="text-[10px] text-slate-400 mt-1">Caution: Creates recurring automatic financial obligations unless cancelled within strict notice bounds.</p>
                </div>

                {/* Red Clause Card */}
                <div className="p-4 bg-slate-800/60 border-l-4 border-rose-500 rounded-xl">
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="w-2 h-2 rounded-full bg-rose-500"></span>
                    <span className="text-xs font-bold text-rose-500 tracking-wider">🔴 RED — CRITICAL RISKS</span>
                  </div>
                  <p className="text-xs font-medium italic text-slate-300">"The Contractor shall assume all liabilities and pay Apex flat damages of $50,000 for any leak."</p>
                  <p className="text-[10px] text-slate-400 mt-1">Danger:Predatory damages and unfair liabilities. Highly restricted moral rights risk model.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Future Vision Features Box */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h3 className="text-xs font-bold text-indigo-600 uppercase tracking-widest mb-2">FUTURE HORIZONS</h3>
            <h4 className="text-3xl font-bold tracking-tight text-slate-900">
              Innovative Features in Development
            </h4>
            <p className="text-sm text-slate-500 mt-2">
              Our engineering team is mapping the next stage of our intelligent assistant. Here is what is arriving soon:
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {futureFeatures.map((ff, index) => (
              <div key={index} className="p-6 rounded-2xl bg-indigo-50/40 border border-indigo-100 hover:bg-indigo-50 hover:shadow-md transition-all">
                <h6 className="font-bold text-indigo-950 text-sm mb-2">{ff.title}</h6>
                <p className="text-xs text-indigo-950/70 leading-relaxed font-semibold">{ff.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 5. Testimonials Section */}
      <section className="py-16 bg-slate-50 border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <h3 className="text-xs font-bold text-indigo-600 uppercase tracking-widest mb-2">USER TESTIMONIALS</h3>
            <h4 className="text-2xl sm:text-3xl font-bold text-slate-900">What our community is saying</h4>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((test, idx) => (
              <div key={idx} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-1 mb-4 text-amber-500">
                    {[...Array(test.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                    ))}
                  </div>
                  <p className="text-xs text-slate-600 italic leading-relaxed font-medium mb-4">"{test.quote}"</p>
                </div>
                <div className="flex items-center gap-3 pt-4 border-t border-slate-100">
                  <div className="w-9 h-9 rounded-full bg-indigo-50 text-indigo-700 font-bold text-xs flex items-center justify-center">
                    {test.author.charAt(0)}
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-slate-900">{test.author}</h5>
                    <p className="text-[10px] text-slate-400 font-medium">{test.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 6. Legal FAQs Section */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-14">
            <HelpCircle className="w-10 h-10 text-indigo-600 mx-auto mb-3" />
            <h3 className="text-2xl sm:text-3xl font-bold text-slate-900">Frequently Asked Questions</h3>
            <p className="text-xs text-slate-400 mt-1">Clear insights on how our system handles, structures, and protects documents.</p>
          </div>

          <div className="space-y-4">
            {faqs.map((faq, index) => {
              const isOpen = activeFaq === index;
              return (
                <div 
                  key={index} 
                  className="border border-slate-200 rounded-xl overflow-hidden transition-all duration-200"
                >
                  <button
                    onClick={() => setActiveFaq(isOpen ? null : index)}
                    className="w-full p-4 text-left flex items-center justify-between text-slate-800 bg-slate-50 hover:bg-slate-100/80 font-bold text-xs sm:text-sm"
                  >
                    <span>{faq.q}</span>
                    <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${isOpen ? "rotate-180" : ""}`} />
                  </button>
                  {isOpen && (
                    <p className="p-4 text-xs font-medium text-slate-500 leading-relaxed bg-white border-t border-slate-100">
                      {faq.a}
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Footer Section */}
      <footer className="bg-slate-900 text-white border-t border-slate-800 py-12">
        <div className="max-w-7xl mx-auto px-4 text-center space-y-6">
          <div className="flex items-center justify-center gap-2">
            <ShieldCheck className="w-6 h-6 text-indigo-400" />
            <span className="font-extrabold text-lg tracking-tight">LegalMind Co-Pilot</span>
          </div>
          <p className="text-[11px] text-slate-400 max-w-2xl mx-auto leading-relaxed">
            LegalMind supports standard legal document processing and simple translation. 
            All contents generated are configured for educational purposes and do not equate to qualified lawyer recommendations.
          </p>
          <div className="text-[10px] text-slate-500 font-medium">
            &copy; 1888-2026 LegalMind AI. Developed securely in compliance with privacy models under standard cloud encryption guidelines.
          </div>
        </div>
      </footer>
    </div>
  );
}
