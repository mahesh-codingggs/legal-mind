import React, { useState } from "react";
import { 
  ShieldAlert, Sparkles, FileText, ChevronRight, MessageSquare, 
  Send, HelpCircle, Check, AlertCircle, FileDown, CheckCircle, 
  Printer, Coins, Landmark, Calendar, RefreshCw, Languages 
} from "lucide-react";
import { DocumentAnalysis, ChatMessage, RiskLevel, LegalClause } from "../types";

interface AnalysisViewProps {
  analysis: DocumentAnalysis;
  chatHistory: ChatMessage[];
  onSendMessage: (text: string) => void;
  isChatLoading: boolean;
  onDownloadReport?: () => void;
  activeLanguage: string;
}

export default function AnalysisView({ 
  analysis, 
  chatHistory, 
  onSendMessage, 
  isChatLoading,
  activeLanguage
}: AnalysisViewProps) {
  const [summaryType, setSummaryType] = useState<"short" | "medium" | "detailed" | "bullets">("medium");
  const [clauseFilter, setClauseFilter] = useState<"ALL" | RiskLevel.RED | RiskLevel.YELLOW | RiskLevel.GREEN>("ALL");
  const [userQuestion, setUserQuestion] = useState("");
  const [showPrintReport, setShowPrintReport] = useState(false);

  // Chat rapid click helper questions
  const chatScaffolds = [
    "Is this safe to sign?",
    "Can I negotiate the obligations?",
    "What happens if I terminate early?",
    "Explain the liabilities simply.",
    "Are there hidden ongoing costs?"
  ];

  const handleSendScaffold = (scaffold: string) => {
    if (isChatLoading) return;
    onSendMessage(scaffold);
  };

  const handleSendCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userQuestion.trim() || isChatLoading) return;
    onSendMessage(userQuestion);
    setUserQuestion("");
  };

  // Filter clauses logic
  const filteredClauses = clauseFilter === "ALL" 
    ? analysis.clauses 
    : analysis.clauses.filter(clause => clause.rating === clauseFilter);

  // Risk Score Color mapping
  const getRiskColor = (score: number) => {
    if (score < 25) return { border: "border-emerald-200", bg: "bg-emerald-50", text: "text-emerald-700", fill: "fill-emerald-500", raw: "#10b981" };
    if (score < 65) return { border: "border-amber-200", bg: "bg-amber-50", text: "text-amber-700", fill: "fill-amber-500", raw: "#f59e0b" };
    return { border: "border-rose-200", bg: "bg-rose-50", text: "text-rose-750", fill: "fill-rose-500", raw: "#f43f5e" };
  };

  const rColor = getRiskColor(analysis.riskScore);

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      
      {/* 1. PDF Printable Report Modal / Overlap */}
      {showPrintReport && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm p-4 sm:p-10 flex items-center justify-center">
          <div className="bg-white text-slate-900 max-w-4xl w-full rounded-2xl shadow-2xl overflow-hidden print:shadow-none print:rounded-none">
            {/* Header panel */}
            <div className="p-6 bg-slate-900 text-white flex justify-between items-center print:bg-white print:text-black print:p-2 border-b border-slate-200">
              <div>
                <span className="text-[10px] uppercase font-mono tracking-wider text-indigo-400">Official Education Report</span>
                <h3 className="text-lg font-black">{analysis.title}</h3>
              </div>
              <div className="flex gap-2 print:hidden">
                <button
                  onClick={handlePrint}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 font-bold text-xs rounded-xl flex items-center gap-1.5 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Print/Save PDF
                </button>
                <button
                  onClick={() => setShowPrintReport(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 hover:text-white font-bold text-xs rounded-xl cursor-pointer"
                >
                  Exit Report
                </button>
              </div>
            </div>

            {/* Print Body (Standard clean black & white format with score color badges) */}
            <div className="p-8 sm:p-12 space-y-8 max-h-[80vh] overflow-y-auto print:max-h-none print:overflow-visible">
              <div className="flex flex-col sm:flex-row justify-between items-start gap-4 border-b border-slate-100 pb-6">
                <div>
                  <h4 className="text-xl font-bold tracking-tight">LegalMind Document Report</h4>
                  <p className="text-xs text-slate-400 mt-0.5">Calculated At: {new Date(analysis.uploadedAt).toLocaleDateString()} | Active Language: {activeLanguage}</p>
                  <p className="text-xs text-slate-700 mt-2"><strong>Document Type:</strong> {analysis.documentType} | <strong>Source Language:</strong> {analysis.language}</p>
                </div>
                <div className="px-5 py-3 border border-slate-200 rounded-xl bg-slate-50 text-center select-none">
                  <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block">Risk Rating</span>
                  <span className="text-2xl font-black block" style={{ color: rColor.raw }}>{analysis.riskScore}/100</span>
                  <span className="text-[10px] uppercase font-extrabold text-slate-600 block">{analysis.riskLabel}</span>
                </div>
              </div>

              {/* Analysis Summaries */}
              <div className="space-y-2">
                <h5 className="text-sm font-bold uppercase tracking-wider text-slate-800">1. Executive Summary</h5>
                <p className="text-xs text-slate-600 leading-relaxed font-semibold">{analysis.summary.detailed}</p>
              </div>

              {/* Warnings List & Clauses */}
              <div className="space-y-4">
                <h5 className="text-sm font-bold uppercase tracking-wider text-slate-800">2. Critical Clause Warnings</h5>
                <div className="space-y-3">
                  {analysis.clauses.map((clause, idx) => (
                    <div key={idx} className="p-4 border border-slate-200 rounded-lg space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-xs font-bold text-slate-800 uppercase tracking-wide">Clause #{idx+1} — {clause.category}</span>
                        <span className="text-[10px] font-bold uppercase">Rating: {clause.rating}</span>
                      </div>
                      <p className="text-[11px] text-slate-400 font-mono italic">"{clause.originalText}"</p>
                      <p className="text-xs text-slate-800 bg-slate-50 p-2.5 rounded-md font-semibold"><strong>Plain English:</strong> {clause.simplifiedText}</p>
                      <p className="text-xs text-slate-500 font-medium leading-relaxed"><strong>AI Advisory:</strong> {clause.explanation}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recommendations */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-slate-100">
                <div className="space-y-2">
                  <h5 className="text-xs font-bold uppercase tracking-widest text-slate-700">What to Negotiate</h5>
                  <ul className="space-y-1.5">
                    {analysis.recommendations.thingsToNegotiate.map((n, i) => (
                      <li key={i} className="text-xs text-slate-600 list-disc ml-4 font-semibold">{n}</li>
                    ))}
                  </ul>
                </div>
                <div className="space-y-2">
                  <h5 className="text-xs font-bold uppercase tracking-widest text-slate-700">Recommended Next Steps</h5>
                  <ul className="space-y-1.5">
                    {analysis.recommendations.suggestedNextSteps.map((s, i) => (
                      <li key={i} className="text-xs text-slate-600 list-disc ml-4 font-semibold">{s}</li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Disclaimer */}
              <div className="p-4 bg-amber-50 border border-amber-100 rounded-lg text-[10px] text-amber-900 leading-relaxed font-semibold">
                <strong>Disclaimer Notice:</strong> LegalMind delivers automated interpretations utilizing multi-pass transformers. This report compiles general educational information but is distinct from official certified paralegal representation or attorney consultation. Always request advice from a legal organization for real actions.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main Analysis Visuals Header */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        
        {/* Left Column (2-Span): Document details, summary tabs, clause highlighters, recommendations */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Document Identity Banner */}
          <div className="p-6 bg-white border border-slate-200/80 rounded-2xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div className="space-y-1">
              <span className="text-[10px] font-black text-indigo-700 bg-indigo-50 border border-indigo-100 px-3 py-1 rounded-full uppercase tracking-wide">
                {analysis.documentType}
              </span>
              <h3 className="text-xl font-extrabold text-slate-900">{analysis.title}</h3>
              <p className="text-xs text-slate-400 font-medium flex items-center gap-1">
                <Languages className="w-3.5 h-3.5 text-slate-300" />
                Original Language: <span className="font-semibold text-slate-600">{analysis.language}</span> 
                {activeLanguage !== "English" && (
                  <span className="text-indigo-600 font-bold ml-1">| Translated into {activeLanguage}</span>
                )}
              </p>
            </div>

            <div className="flex gap-2 shrink-0">
              <button
                onClick={() => setShowPrintReport(true)}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs rounded-xl shadow-xs inline-flex items-center gap-1.5 transition-transform hover:-translate-y-0.5 cursor-pointer"
              >
                <FileDown className="w-4 h-4 text-indigo-300" />
                Generate PDF Report
              </button>
            </div>
          </div>

          {/* 2. Interactive AI Summaries Panel */}
          <div className="p-6 bg-white border border-slate-200/80 rounded-2xl space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between border-b border-slate-100 pb-3 gap-2">
              <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-indigo-500" />
                AI-Driven Document Summaries
              </h4>
              
              {/* Type Switch tabs */}
              <div className="flex flex-wrap items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200">
                <button
                  onClick={() => setSummaryType("short")}
                  className={`px-2.5 py-1 text-[10px] font-bold rounded-md transition-colors ${summaryType === "short" ? "bg-white text-slate-950 font-black shadow-xs" : "text-slate-500 hover:text-slate-800"}`}
                >
                  Short
                </button>
                <button
                  onClick={() => setSummaryType("medium")}
                  className={`px-2.5 py-1 text-[10px] font-bold rounded-md transition-colors ${summaryType === "medium" ? "bg-white text-slate-950 font-black shadow-xs" : "text-slate-500 hover:text-slate-800"}`}
                >
                  Medium
                </button>
                <button
                  onClick={() => setSummaryType("detailed")}
                  className={`px-2.5 py-1 text-[10px] font-bold rounded-md transition-colors ${summaryType === "detailed" ? "bg-white text-slate-950 font-black shadow-xs" : "text-slate-500 hover:text-slate-800"}`}
                >
                  Detailed
                </button>
                <button
                  onClick={() => setSummaryType("bullets")}
                  className={`px-2.5 py-1 text-[10px] font-bold rounded-md transition-colors ${summaryType === "bullets" ? "bg-white text-slate-950 font-black shadow-xs" : "text-slate-500 hover:text-slate-800"}`}
                >
                  Bullet Points
                </button>
              </div>
            </div>

            <div className="text-xs text-slate-650 leading-relaxed font-semibold transition-all">
              {summaryType === "short" && <p>{analysis.summary.short}</p>}
              {summaryType === "medium" && <p>{analysis.summary.medium}</p>}
              {summaryType === "detailed" && <p className="whitespace-pre-line">{analysis.summary.detailed}</p>}
              {summaryType === "bullets" && (
                <ul className="space-y-2">
                  {analysis.summary.bulletPoints?.map((pt, i) => (
                    <li key={i} className="flex gap-2 items-start font-medium leading-relaxed">
                      <CheckCircle className="w-3.5 h-3.5 text-indigo-500 shrink-0 mt-0.5" />
                      <span>{pt}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>

          {/* 3. Color Highlighting System Block */}
          <div className="p-6 bg-white border border-slate-200/80 rounded-2xl space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-3 border-b border-slate-100 gap-3">
              <div>
                <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest block">Contract Clause Inspector</h4>
                <p className="text-[10px] font-medium text-slate-400 mt-0.5">Filter by identified legal liabilities, payments, and standard agreements.</p>
              </div>

              {/* Clause Filter dropdown tabs */}
              <div className="flex flex-wrap items-center bg-slate-100/50 border border-slate-150 p-1 rounded-xl text-[10px] font-bold gap-1 shadow-sm">
                <button
                  onClick={() => setClauseFilter("ALL")}
                  className={`px-2 py-1 rounded-lg ${clauseFilter === "ALL" ? "bg-slate-900 text-white font-black" : "text-slate-600 hover:bg-slate-200"}`}
                >
                  Show All
                </button>
                <button
                  onClick={() => setClauseFilter(RiskLevel.RED)}
                  className={`px-2.5 py-1 rounded-lg flex items-center gap-1 ${clauseFilter === RiskLevel.RED ? "bg-rose-500 text-white font-black" : "text-rose-600 hover:bg-rose-50/50"}`}
                >
                  🟢 🔴 Risks
                </button>
                <button
                  onClick={() => setClauseFilter(RiskLevel.YELLOW)}
                  className={`px-2.5 py-1 rounded-lg flex items-center gap-1 ${clauseFilter === RiskLevel.YELLOW ? "bg-amber-500 text-white font-black" : "text-amber-600 hover:bg-amber-50/50"}`}
                >
                  🟢 🟡 Cautions
                </button>
                <button
                  onClick={() => setClauseFilter(RiskLevel.GREEN)}
                  className={`px-2.5 py-1 rounded-lg flex items-center gap-1 ${clauseFilter === RiskLevel.GREEN ? "bg-emerald-600 text-white font-black" : "text-emerald-700 hover:bg-emerald-50/50"}`}
                >
                  🟢 Safe Terms
                </button>
              </div>
            </div>

            {/* List of matched items */}
            <div className="space-y-4">
              {filteredClauses.length > 0 ? (
                filteredClauses.map((clause) => {
                  const isRed = clause.rating === RiskLevel.RED;
                  const isYellow = clause.rating === RiskLevel.YELLOW;
                  
                  return (
                    <div 
                      key={clause.id || Math.random().toString()}
                      className={`p-5 rounded-2xl border transition-all flex items-start gap-4 ${
                        isRed ? "bg-rose-50/30 border-rose-200" :
                        isYellow ? "bg-amber-50/30 border-amber-200" :
                        "bg-emerald-50/20 border-emerald-100"
                      }`}
                      id={`clause-highlight-${clause.id}`}
                    >
                      {/* Left icon wrapper */}
                      <div className={`p-2.5 rounded-xl shrink-0 ${
                        isRed ? "bg-rose-100 text-rose-650" :
                        isYellow ? "bg-amber-100 text-amber-650" :
                        "bg-emerald-100 text-emerald-650"
                      }`}>
                        <ShieldAlert className="w-5 h-5 shrink-0" />
                      </div>

                      {/* Right details wrapper */}
                      <div className="space-y-2.5 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] uppercase font-black tracking-wider text-slate-400">Category: {clause.category}</span>
                          <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-full ${
                            isRed ? "bg-rose-100 text-rose-700" :
                            isYellow ? "bg-amber-100 text-amber-700" :
                            "bg-emerald-100 text-emerald-700"
                          }`}>
                            {isRed ? "🔴 High Risk" : isYellow ? "🟡 Needs Attention" : "🟢 Fair Term"}
                          </span>
                        </div>

                        {/* Legal terms code */}
                        <div className="p-3 bg-slate-50 border border-slate-100 rounded-xl">
                          <p className="text-[10px] text-slate-450 font-mono italic">
                            "{clause.originalText}"
                          </p>
                        </div>

                        {/* Explained in simplified words */}
                        <div className="space-y-1">
                          <h5 className="text-[10px] font-black text-slate-500 uppercase tracking-wider">Converted Translation (Plain language)</h5>
                          <p className="text-xs text-slate-800 font-extrabold">
                            {clause.simplifiedText}
                          </p>
                        </div>

                        {/* Why is this warning */}
                        <p className="text-xs text-slate-500 leading-relaxed font-semibold">
                          <strong>Analytical Reasoning:</strong> {clause.explanation}
                        </p>
                      </div>
                    </div>
                  );
                })
              ) : (
                <p className="text-xs text-slate-400 italic text-center py-6">No clauses matched the selected risk filter.</p>
              )}
            </div>
          </div>

          {/* 4. Actionable recommendations & checklists */}
          <div className="p-6 bg-white border border-slate-200/80 rounded-2xl space-y-5">
            <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest border-b border-slate-100 pb-3 flex items-center gap-1.5">
              <CheckCircle className="w-4 h-4 text-emerald-600" />
              Strategic Recommendations Checklist
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Box 1: Things to negotiate */}
              <div className="p-4 bg-slate-50 border border-slate-150 rounded-xl space-y-2.5">
                <span className="text-[10px] font-bold text-slate-400 tracking-wider uppercase block">Things to modify/negotiate</span>
                <ul className="space-y-1.5">
                  {analysis.recommendations.thingsToNegotiate?.map((item, idx) => (
                    <li key={idx} className="flex gap-2 items-start font-medium text-xs leading-relaxed text-slate-650">
                      <span className="p-0.5 bg-indigo-50 text-indigo-700 rounded-md shrink-0 mt-0.5">
                        <ChevronRight className="w-3 h-3" />
                      </span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Box 2: Questions to ask */}
              <div className="p-4 bg-slate-50 border border-slate-150 rounded-xl space-y-2.5">
                <span className="text-[10px] font-bold text-slate-400 tracking-wider uppercase block">Questions to ask before signing</span>
                <ul className="space-y-1.5">
                  {analysis.recommendations.thingsToAsk?.map((item, idx) => (
                    <li key={idx} className="flex gap-2 items-start font-medium text-xs leading-relaxed text-slate-650">
                      <span className="p-0.5 bg-indigo-50 text-indigo-700 rounded-md shrink-0 mt-0.5">
                        <ChevronRight className="w-3 h-3" />
                      </span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Box 3: Important questions */}
              <div className="p-4 bg-slate-50 border border-slate-150 rounded-xl space-y-2.5">
                <span className="text-[10px] font-bold text-slate-400 tracking-wider uppercase block">Important considerations</span>
                <ul className="space-y-1.5">
                  {analysis.recommendations.importantQuestions?.map((item, idx) => (
                    <li key={idx} className="flex gap-2 items-start font-medium text-xs leading-relaxed text-slate-650">
                      <span className="p-0.5 bg-indigo-50 text-indigo-700 rounded-md shrink-0 mt-0.5">
                        <ChevronRight className="w-3 h-3" />
                      </span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Box 4: Missing Information */}
              <div className="p-4 bg-slate-50 border border-slate-150 rounded-xl space-y-2.5">
                <span className="text-[10px] font-bold text-slate-400 tracking-wider uppercase block">Missing details / standard rules absent</span>
                <ul className="space-y-1.5">
                  {analysis.recommendations.missingInformation?.map((item, idx) => (
                    <li key={idx} className="flex gap-2 items-start font-medium text-xs leading-relaxed text-slate-650">
                      <span className="p-0.5 bg-rose-50 text-rose-700 rounded-md shrink-0 mt-0.5">
                        <AlertCircle className="w-3 h-3" />
                      </span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Suggested next steps list */}
            <div className="p-4 bg-indigo-50/40 border border-indigo-100 rounded-xl space-y-2">
              <span className="text-[10px] font-extrabold text-indigo-950 uppercase tracking-widest block">Suggested Actionable Next Steps</span>
              <div className="flex flex-col sm:flex-row gap-3">
                {analysis.recommendations.suggestedNextSteps?.map((step, idx) => (
                  <div key={idx} className="flex-1 bg-white border border-indigo-100 p-3 rounded-lg text-xs leading-relaxed font-semibold text-indigo-900 flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                    <span>{step}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column (1-Span): Meter score dial, Live Conversation chat widget */}
        <div className="space-y-6">
          
          {/* 5. Clean dial meter risk score */}
          <div className="p-6 bg-white border border-slate-200/80 rounded-2xl text-center space-y-4">
            <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest block">Overall Risk Index</h4>
            
            {/* Real SVG Circular progress meter dial */}
            <div className="relative w-40 h-40 mx-auto flex items-center justify-center select-none">
              <svg className="w-full h-full transform -rotate-90">
                {/* Background tracks */}
                <circle 
                  cx="80" 
                  cy="80" 
                  r="64" 
                  stroke="#e2e8f0" 
                  strokeWidth="10" 
                  fill="transparent" 
                />
                {/* Colored Risk arcs */}
                <circle 
                  cx="80" 
                  cy="80" 
                  r="64" 
                  stroke={rColor.raw} 
                  strokeWidth="10" 
                  fill="transparent" 
                  strokeDasharray={`${2*Math.PI*64}`}
                  strokeDashoffset={`${2 * Math.PI * 64 * (1 - analysis.riskScore / 100)}`}
                  className="transition-all duration-1000 ease-out"
                  strokeLinecap="round"
                />
              </svg>
              {/* Inner details labels */}
              <div className="absolute inset-0 flex flex-col items-center justify-center leading-none">
                <span className="text-4xl font-black text-slate-900 leading-tight">{analysis.riskScore}</span>
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Score index</span>
              </div>
            </div>

            {/* Safety tags and warnings */}
            <div className={`p-3 rounded-xl border font-bold text-xs ${rColor.border} ${rColor.bg} ${rColor.text}`}>
              <span className="uppercase tracking-widest">{analysis.riskLabel}</span>
              {analysis.riskScore >= 65 && <p className="text-[10px] font-semibold text-rose-500 leading-tight mt-1"> Predatory clauses identified. Consider requesting revision before signing. </p>}
              {analysis.riskScore >= 25 && analysis.riskScore < 65 && <p className="text-[10px] font-semibold text-amber-500 leading-tight mt-1"> Standard layout with auto-bills or restricted notice clauses. Check details. </p>}
              {analysis.riskScore < 25 && <p className="text-[10px] font-semibold text-emerald-600 leading-tight mt-1"> Fully normal contract balancing bilateral responsibilities nicely. </p>}
            </div>
          </div>

          {/* 6. AI Conversational Assistant Panel */}
          <div className="p-5 bg-white border border-slate-200/80 rounded-2xl flex flex-col h-[520px] shadow-sm">
            {/* Header info */}
            <div className="border-b border-slate-100 pb-3 mb-3 shrink-0">
              <h4 className="text-xs font-black text-slate-900 flex items-center gap-1.5 uppercase tracking-wide">
                <MessageSquare className="w-4 h-4 text-indigo-500" />
                LegalMind Chat Companion
              </h4>
              <p className="text-[10px] text-slate-400 mt-0.5 leading-normal">
                Ask localized inquiries or clarify exact sections from your uploaded draft terms.
              </p>
            </div>

            {/* Chat message display window */}
            <div className="flex-1 overflow-y-auto space-y-3.5 pr-1.5 scrollbar-thin text-xs">
              {chatHistory.length === 0 ? (
                <div className="text-center py-10 space-y-1.5 mt-8 text-slate-400 font-semibold select-none">
                  <HelpCircle className="w-8 h-8 mx-auto text-slate-350" />
                  <p>Inquire anything about this contract.</p>
                  <p className="text-[9px] text-slate-400 leading-relaxed font-normal">
                    Or select a rapid prompt block to start immediately:
                  </p>
                </div>
              ) : (
                chatHistory.map((msg) => (
                  <div 
                    key={msg.id}
                    className={`flex flex-col max-w-[85%] rounded-2xl p-3 ${
                      msg.sender === "user" 
                        ? "bg-slate-900 text-white rounded-tr-none ml-auto" 
                        : "bg-slate-50 border border-slate-200 text-slate-800 rounded-tl-none mr-auto font-medium"
                    }`}
                  >
                    <p className="whitespace-pre-wrap leading-relaxed text-[11px] font-semibold">{msg.text}</p>
                    <span className="text-[8px] opacity-60 self-end mt-1 font-mono">{msg.timestamp}</span>
                  </div>
                ))
              )}
              {isChatLoading && (
                <div className="bg-slate-50 border border-slate-100 max-w-[60%] rounded-2xl rounded-tl-none p-3 mr-auto flex items-center gap-2 text-slate-400 font-bold">
                  <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce"></span>
                  <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:0.2s]"></span>
                  <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:0.4s]"></span>
                  <span className="text-[10px] font-semibold">LegalMind is explaining...</span>
                </div>
              )}
            </div>

            {/* Scaffold quick actions list */}
            {chatHistory.length === 0 && (
              <div className="flex flex-wrap gap-1.5 py-4 border-t border-slate-50 shrink-0">
                {chatScaffolds.map((scaff, i) => (
                  <button
                    key={i}
                    onClick={() => handleSendScaffold(scaff)}
                    disabled={isChatLoading}
                    className="px-2.5 py-1.5 bg-slate-100 hover:bg-indigo-50 border border-slate-200 hover:border-indigo-150 rounded-xl text-[10px] font-bold text-slate-700 hover:text-indigo-950 text-left transition-colors cursor-pointer"
                  >
                    {scaff}
                  </button>
                ))}
              </div>
            )}

            {/* Form messaging input fields */}
            <form onSubmit={handleSendCustom} className="pt-3 border-t border-slate-100 mt-2 shrink-0 flex items-center gap-2">
              <input
                type="text"
                value={userQuestion}
                onChange={(e) => setUserQuestion(e.target.value)}
                disabled={isChatLoading}
                placeholder="Ask e.g. Is clause #3 safe to sign?"
                className="flex-1 px-3 py-2 text-xs font-semibold bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900"
              />
              <button
                type="submit"
                disabled={isChatLoading || !userQuestion.trim()}
                className="p-2.5 bg-slate-900 border border-slate-950 rounded-xl text-white hover:bg-slate-800 disabled:bg-slate-200 transition-colors shadow-xs cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
