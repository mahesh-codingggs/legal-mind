import React from "react";
import { mockTemplates } from "../data/mockTemplates";
import { FileText, ArrowRight, ShieldCheck, HelpCircle } from "lucide-react";
import { LegalTemplate } from "../types";

interface LegalTemplatesProps {
  onSelectTemplate: (template: LegalTemplate) => void;
  isLoading: boolean;
}

export default function LegalTemplates({ onSelectTemplate, isLoading }: LegalTemplatesProps) {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="mb-10 text-center sm:text-left">
        <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2 justify-center sm:justify-start">
          <FileText className="w-7 h-7 text-indigo-600" />
          Interactive Legal Templates
        </h2>
        <p className="text-sm text-slate-500 mt-1 max-w-2xl leading-relaxed">
          Don't have a legal document handy? Choose from our pre-loaded training templates. 
          Each represents real-world clauses to demonstrate risk states, summaries, and translations.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {mockTemplates.map((tpl) => (
          <div 
            key={tpl.id}
            className="flex flex-col justify-between p-6 bg-white border border-slate-200 hover:border-slate-300 hover:shadow-lg rounded-2xl transition-all group"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-indigo-700 bg-indigo-50 border border-indigo-100 rounded-full px-2.5 py-1 uppercase tracking-wide">
                  {tpl.category}
                </span>
                <span className="text-xs text-slate-400 font-medium flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" /> Demo Safe
                </span>
              </div>
              <h3 className="text-base font-extrabold text-slate-900 group-hover:text-indigo-600 transition-colors">
                {tpl.title}
              </h3>
              <p className="text-xs text-slate-550 leading-relaxed font-medium">
                {tpl.description}
              </p>
              
              {/* Preview of contract starting text snippet */}
              <div className="p-3 bg-slate-50 border border-slate-100 rounded-xl">
                <p className="text-[10px] text-slate-400 font-mono line-clamp-3">
                  {tpl.rawText}
                </p>
              </div>
            </div>

            <div className="pt-5 mt-4 border-t border-slate-100 flex items-center justify-between">
              <span className="text-[10px] font-semibold text-slate-400 flex items-center gap-1 uppercase">
                <HelpCircle className="w-3.5 h-3.5 text-slate-350" /> Fully Custom Explainers
              </span>
              <button
                onClick={() => onSelectTemplate(tpl)}
                disabled={isLoading}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-slate-900 border border-slate-950 rounded-xl hover:bg-slate-800 disabled:bg-slate-300 transition-all cursor-pointer"
              >
                {isLoading ? "Running Analysis..." : "Analyze Contract"}
                <ArrowRight className="w-3.5 h-3.5 text-slate-300" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
