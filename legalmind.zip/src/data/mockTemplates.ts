import { LegalTemplate } from "../types";

export const mockTemplates: LegalTemplate[] = [
  {
    id: "template_nda",
    title: "Standard Non-Disclosure Agreement (One-Sided)",
    category: "Corporate",
    description: "A highly restrictive NDA protecting proprietary startup data with intense penalties and lifetime confidentiality terms.",
    rawText: `MUTUAL NON-DISCLOSURE AND CONFIDENTIALITY AGREEMENT

This Non-Disclosure Agreement (the "Agreement") is entered into as of June 18, 2026, by and between Apex Tech Ventures, LLC ("Disclosing Party"), and John Doe ("Receiving Party").

1. Confidential Information. Confidential Information includes all technical, financial, or business secrets, software code, customer lists, and product strategies disclosed by the Disclosing Party.
2. Term of Obligation. The obligations of Receiving Party to protect Confidential Information shall persist in perpetuity from the date of final disclosure, notwithstanding the contract termination.
3. Liquidated Damages. In the event of any unauthorized leak, breach, or disclosure of Confidential Information by the Receiving Party, the Receiving Party shall immediately pay to the Disclosing Party a flat penalty fee of $50,000 as liquidated damages, without any requirement on the part of Disclosing Party to prove actual documentable damages.
4. Unilateral Intellectual Property Assignment. Any feedback, upgrades, or code suggestions proposed by the Receiving Party regarding Apex Tech Ventures products during the term of relation will instantly and unilaterally become the sole property of Apex Tech Ventures without further consideration.
5. Governing Law and Dispute Venue. This Agreement is governed by the laws of Del Mar, Delaware, and any disputes shall be settled exclusively in courts situated in Del Mar, with Receiving Party waiving all rights to jury trial and agreeing to assume all legal defense fees of Apex Tech Ventures in case of litigations.`
  },
  {
    id: "template_lease",
    title: "Residential Lease Agreement (Landlord-Favorable)",
    category: "Real Estate",
    description: "A typical tenant lease that includes auto-renewals, hidden maintenance fees, and immediate termination conditions without notice.",
    rawText: `RESIDENTIAL LEASE AGREEMENT

This Agreement is made on June 18, 2026, between Oakwood Realty Assets ("Lessor") and Resident Tenant ("Lessee").

1. Demised Premises. Lessor leases to Lessee Apartment 4B, 128 Maple Lane.
2. Rental Term and Automatic Renewal. This Lease is for a term of 12 months. It shall AUTOMATICALLY RENEW for consecutive 12-month periods on the same rates unless Lessee provides written registered mail cancellation notice exactly 90 days prior to expiration.
3. Security Deposit. Lessee deposits $3,000. In case of early evacuation, Lessee forfeits the entirety of this deposit as administrative liquidation.
4. Maintenance and Access Rights. Tenant is solely responsible for all repairs under $500. Additionally, Lessor retains absolute keys and right of entry without prior notice at any hour for safety examinations or aesthetic enhancements.
5. Fees and Late Penalties. Rent is payable on the 1st of each month. A late fee of $150 per day shall accumulate starting on the 2nd day of delinquency.
6. Termination on Default. Lessor reserves the right to terminate this lease instantly with 24 hours notice if lessee breaks any rule, including playing music above 50 decibels or having guests stay overnight.`
  },
  {
    id: "template_freelance",
    title: "Freelance Service Agreement (Client-Favorable)",
    category: "Freelance",
    description: "An agreement that restricts freelancer rights, imposes infinite revisions, and delays payments on whim.",
    rawText: `FREELANCE CONTENT CREATION CONTRACT

This Agreement is made between NextGen Media Corp ("Client") and Creative Freelancer ("Contractor").

1. Services and Deliverables. Contractor shall create 15 custom articles and video packages as detailed in Exhibit A.
2. Infinite Iterations. Freelancer agrees to provide unlimited revisions and adjustments to all deliverables at no extra charge, until NextGen Media Corp's editorial committee declares formal client-side acceptance.
3. Payment Schedule. Contractor will be paid fee of $2,500 total. Invoices shall be processed net-90 days following final full team approval. Client reserves right to hold payments indefinitely if client projects are delayed.
4. Transfer of Rights. Contractor assigns all digital copyrights, moral rights, and patentable assets of deliverables to Client upon raw file submission. Contractor is strictly restricted from showcasing these items in public design portfolios due to strict confidentiality guidelines.
5. No Solicitation & Non-Compete. Contractor agrees that during the term and for 5 years thereafter, Contractor will not create materials or offer freelance consultation to any competitor in the digital marketing industry globally.`
  },
  {
    id: "template_employment",
    title: "Executive Employment Agreement (Standard Fair)",
    category: "Employment",
    description: "A standard corporate employment agreement containing standard notice periods, health perks, and reasonable IP constraints.",
    rawText: `EXECUTIVE EMPLOYMENT AGREEMENT

This Agreement is made on June 18, 2026, between Pillar Global Technologies ("Employer") and Candidate Hire ("Employee").

1. Position and Scope. Employee is hired as Senior Software Architect.
2. Compensation. Employee shall receive base salary of $120,000 per annum, paid bi-weekly, along with regular dental and standard physical healthcare insurance options.
3. Work Inventions. Any software designs created by the Employee during standard working hours using company computers shall remain the property of the Employer. Works created on employee's private personal laptops on off-hours do not apply.
4. Termination with Notice. Either party may terminate employment with 30 days written notice. In the event of immediate termination without cause, Employer will issue a standard severance pack of 2 months salary.
5. Non-Disclosure. Employee agrees to protect the trade secrets of Pillar Global Technologies and will not leak internal client data structures.`
  }
];
