import React, { useState, useEffect } from "react";
import Navbar from "./components/Navbar";
import HeroSection from "./components/HeroSection";
import Dashboard from "./components/Dashboard";
import CompareView from "./components/CompareView";
import LegalTemplates from "./components/LegalTemplates";
import AnalysisView from "./components/AnalysisView";
import AuthModal from "./components/AuthModal";
import { AppUser, SavedAnalysis, ComparisonResult, ChatMessage, LegalTemplate, RiskLevel } from "./types";
import { ArrowLeft, Sparkles, Scale, AlertCircle } from "lucide-react";

export default function App() {
  // Navigation & Sessions States
  const [activeTab, setActiveTab] = useState<"home" | "analyze" | "compare" | "templates">("home");
  const [user, setUser] = useState<AppUser | null>(null);
  const [activeLanguage, setActiveLanguage] = useState("English");
  const [isAuthOpen, setIsAuthOpen] = useState(false);

  // Document/Analysis State Management
  const [savedAnalyses, setSavedAnalyses] = useState<SavedAnalysis[]>([]);
  const [activeAnalysis, setActiveAnalysis] = useState<SavedAnalysis | null>(null);

  // Loadings States
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isComparing, setIsComparing] = useState(false);
  const [isChatLoading, setIsChatLoading] = useState(false);

  // Initializing local configuration on load
  useEffect(() => {
    // Sync pre-saved document lists
    const stored = localStorage.getItem("legalmind_saved_analyses");
    if (stored) {
      try {
        setSavedAnalyses(JSON.parse(stored));
      } catch (e) {
        console.error("Local storage analysis load failed:", e);
      }
    }

    // Sync pre-saved active user sessions
    const storedUser = localStorage.getItem("legalmind_user_session");
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser));
      } catch (e) {
        console.error("Local storage session load failed:", e);
      }
    } else {
      // Auto register a premium demo session to allow fluid instant testing!
      const demoUser: AppUser = {
        email: "guest.explorer@legalmind.ai",
        name: "Guest Explorer",
        isGuest: true,
        avatar: "https://api.dicebear.com/7.x/adventurer/svg?seed=welcome_user"
      };
      setUser(demoUser);
    }
  }, []);

  // Save states helper on mutation
  const persistAnalyses = (newList: SavedAnalysis[]) => {
    setSavedAnalyses(newList);
    localStorage.setItem("legalmind_saved_analyses", JSON.stringify(newList));
  };

  // Auth logins handler
  const handleLoginSuccess = (loginUser: AppUser) => {
    setUser(loginUser);
    localStorage.setItem("legalmind_user_session", JSON.stringify(loginUser));
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem("legalmind_user_session");
    // Clear local lists
    setSavedAnalyses([]);
    setActiveAnalysis(null);
    localStorage.removeItem("legalmind_saved_analyses");
  };

  // Delete analysis permanent
  const handleDeleteAnalysis = (id: string) => {
    const updated = savedAnalyses.filter(item => item.id !== id);
    persistAnalyses(updated);
    if (activeAnalysis && activeAnalysis.id === id) {
      setActiveAnalysis(null);
    }
  };

  // 1. Text Analyzer executor tool
  const handleAnalyzeText = async (rawText: string, title?: string, language?: string) => {
    setIsAnalyzing(true);
    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: rawText,
          title: title || "Pasted Legal Contract",
          language: language || activeLanguage
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData?.error || "Review required: API response returned fatal error status.");
      }

      const analyzedResult = await response.json();
      
      const newSavedItem: SavedAnalysis = {
        id: analyzedResult.id || "doc_" + Date.now(),
        title: analyzedResult.title || title || "Legal Analysis",
        rawText: rawText,
        analysis: analyzedResult,
        chatHistory: [],
        savedAt: new Date().toISOString()
      };

      const updatedList = [newSavedItem, ...savedAnalyses];
      persistAnalyses(updatedList);
      setActiveAnalysis(newSavedItem);
      setActiveTab("analyze");
    } catch (error) {
      console.error("Text analysis triggers failed:", error);
      throw error;
    } finally {
      setIsAnalyzing(false);
    }
  };

  // 2. Multimodal OCR Image scanner executor tool
  const handleAnalyzeImage = async (base64: string, mime: string, title?: string, language?: string) => {
    setIsAnalyzing(true);
    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          imageBase64: base64,
          imageMimeType: mime,
          title: title || "Scanned Screenshot Document",
          language: language || activeLanguage
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData?.error || "Review required: OCR processing response returned fatal level error.");
      }

      const analyzedResult = await response.json();
      
      const newSavedItem: SavedAnalysis = {
        id: analyzedResult.id || "doc_" + Date.now(),
        title: analyzedResult.title || title || "Scanned Photo Document",
        rawText: analyzedResult.rawText || "Parsed text extracted via OCR",
        analysis: analyzedResult,
        chatHistory: [],
        savedAt: new Date().toISOString()
      };

      const updatedList = [newSavedItem, ...savedAnalyses];
      persistAnalyses(updatedList);
      setActiveAnalysis(newSavedItem);
      setActiveTab("analyze");
    } catch (error) {
      console.error("Image OCR triggers failed:", error);
      throw error;
    } finally {
      setIsAnalyzing(false);
    }
  };

  // 3. Dual Contract Draft Comparer pipeline
  const handleCompareContracts = async (text1: string, title1: string, text2: string, title2: string): Promise<ComparisonResult | null> => {
    setIsComparing(true);
    try {
      const response = await fetch("/api/compare", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          doc1Text: text1,
          doc1Title: title1,
          doc2Text: text2,
          doc2Title: title2
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData?.error || "Review required: Comparative analyzer failed to generate matches.");
      }

      const comparisonResult = await response.json();
      return comparisonResult;
    } catch (e) {
      console.error("Comparison executor error:", e);
      throw e;
    } finally {
      setIsComparing(false);
    }
  };

  // 4. Interactive Chat conversation dispatch pipeline
  const handleSendMessage = async (text: string) => {
    if (!activeAnalysis) return;
    
    // Optimistic user bubble append
    const userMsg: ChatMessage = {
      id: "msg_" + Date.now(),
      sender: "user",
      text: text,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    };

    const updatedHistory = [...activeAnalysis.chatHistory, userMsg];
    const itemWithUserBubble = {
      ...activeAnalysis,
      chatHistory: updatedHistory
    };

    // Temporarily update UI
    setActiveAnalysis(itemWithUserBubble);
    setSavedAnalyses(savedAnalyses.map(item => item.id === activeAnalysis.id ? itemWithUserBubble : item));

    setIsChatLoading(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          documentText: activeAnalysis.rawText,
          question: text,
          chatHistory: activeAnalysis.chatHistory,
          language: activeLanguage
        }),
      });

      if (!response.ok) {
        throw new Error("Chat dispatch service failed.");
      }

      const resultData = await response.json();
      const assistantMsg: ChatMessage = {
        id: "msg_" + (Date.now() + 1),
        sender: "ai",
        text: resultData.message,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
      };

      const finalHistory = [...updatedHistory, assistantMsg];
      const finalizedItem = {
        ...activeAnalysis,
        chatHistory: finalHistory
      };

      // Set and Persist active session results
      setActiveAnalysis(finalizedItem);
      
      const newSavedList = savedAnalyses.map(item => item.id === activeAnalysis.id ? finalizedItem : item);
      persistAnalyses(newSavedList);
    } catch (err) {
      console.error("Chat conversation processor failure:", err);
      // Append fail message
      const failMsg: ChatMessage = {
        id: "msg_err_" + Date.now(),
        sender: "ai",
        text: "I experienced communication latency. Please verify your GEMINI_API_KEY limits or try again.",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
      };
      const finalHistory = [...updatedHistory, failMsg];
      const finalizedItem = { ...activeAnalysis, chatHistory: finalHistory };
      setActiveAnalysis(finalizedItem);
    } finally {
      setIsChatLoading(false);
    }
  };

  // Launch analysis on pre-selected legal templates
  const handleSelectTemplate = async (template: LegalTemplate) => {
    try {
      setActiveTab("analyze");
      await handleAnalyzeText(template.rawText, template.title, activeLanguage);
    } catch (e) {
      alert("Template analysis failed. Please verify your Gemini API key.");
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans selection:bg-indigo-100/80">
      
      {/* Universal header brand navbar */}
      <Navbar
        user={user}
        activeLanguage={activeLanguage}
        onLanguageChange={setActiveLanguage}
        onAuthTrigger={() => setIsAuthOpen(true)}
        onLogout={handleLogout}
        activeTab={activeTab}
        onTabChange={(tab) => {
          setActiveTab(tab);
          // If we click templates or compare, clear active analysis so workspace opens clean
          if (tab !== "analyze") {
            setActiveAnalysis(null);
          }
        }}
      />

      {/* Main Container Views routers */}
      <main className="flex-1 bg-slate-50">
        
        {/* VIEW 1: LANDING HOME VIEW */}
        {activeTab === "home" && (
          <HeroSection
            onStartAnalyzing={() => setActiveTab("analyze")}
            onExploreTemplates={() => setActiveTab("templates")}
          />
        )}

        {/* VIEW 2: CONTRACT INTERPRETATION WORKSPACE */}
        {activeTab === "analyze" && (
          <>
            {activeAnalysis ? (
              <div className="space-y-4">
                {/* Back to main upload dashboard bar */}
                <div className="bg-slate-900 text-white py-3">
                  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between text-xs">
                    <button
                      onClick={() => setActiveAnalysis(null)}
                      className="inline-flex items-center gap-1 font-bold text-slate-350 hover:text-white transition-all cursor-pointer"
                    >
                      <ArrowLeft className="w-4 h-4" />
                      Back to Document Workspace
                    </button>
                    <span className="hidden sm:inline text-indigo-400 font-semibold tracking-wide uppercase text-[10px]">Active Educational Review</span>
                  </div>
                </div>

                <AnalysisView
                  analysis={activeAnalysis.analysis}
                  chatHistory={activeAnalysis.chatHistory}
                  onSendMessage={handleSendMessage}
                  isChatLoading={isChatLoading}
                  activeLanguage={activeLanguage}
                />
              </div>
            ) : (
              <Dashboard
                savedAnalyses={savedAnalyses}
                onAnalyzeText={handleAnalyzeText}
                onAnalyzeImage={handleAnalyzeImage}
                onSelectAnalysis={setActiveAnalysis}
                onDeleteAnalysis={handleDeleteAnalysis}
                isLoading={isAnalyzing}
                activeLanguage={activeLanguage}
              />
            )}
          </>
        )}

        {/* VIEW 3: DRAFT COMPARISONS VIEW */}
        {activeTab === "compare" && (
          <CompareView
            onCompare={handleCompareContracts}
            isLoading={isComparing}
          />
        )}

        {/* VIEW 4: SAMPLE EDUCATIONAL CONTRACT TEMPLATES SELECTOR */}
        {activeTab === "templates" && (
          <LegalTemplates
            onSelectTemplate={handleSelectTemplate}
            isLoading={isAnalyzing}
          />
        )}
      </main>

      {/* Authentication Gateway Dialog Modal */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onLoginSuccess={handleLoginSuccess}
      />
    </div>
  );
}
